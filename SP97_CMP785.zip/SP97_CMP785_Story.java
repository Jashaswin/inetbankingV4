package com.compass.pages;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.compass.common.GenericFunctions;

public class SP97_CMP785_Story {


	public WebDriver driver;
	Boolean value;
	String text,text2;
	int i,j;
	int counter=0;
	public GenericFunctions gf;


	public SP97_CMP785_Story(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver, this);
		gf=new GenericFunctions(driver);
	}



	@FindBy(xpath="//dt[normalize-space()='Home']")
	WebElement Home; 
	@FindBy(xpath="//td[normalize-space()='Port Calls']")
	WebElement Port_calls;
	@FindBy(xpath="//div[@class='divTitle']")
	WebElement Title_Port_calls;
	@FindBy(xpath="//div[@class='divTitle']")
	WebElement Ob_Between_Date_Title;
	@FindBy(xpath="//select[@id='cmbVessels']")
	WebElement Vessel;
	@FindBy(xpath="//a[@id='PortCalls']")
	WebElement Cmp_portCall;
	@FindBy(xpath="//input[@id='txtFrom']")
	WebElement Ob_Btw_date_box;
	@FindBy(xpath="//input[@id='txtTo']")
	WebElement Ob_And_date_box;
	@FindBy(xpath="//input[@id='txtFromDate']")
	WebElement Cmp_Before_date_box;
	@FindBy(xpath="(//input[@name='txtToDate'])[1]")
	WebElement Cmp_Aft_date_box;
	@FindBy(xpath="//img[@title='Add']")
	WebElement Cmp_Add;

	@FindBy(xpath="//input[@id='FormView1_req_code']")
	WebElement Port_name; 
	@FindBy(xpath="//input[@id='FormView1_txtETA']")
	WebElement ETA_box; 
	@FindBy(xpath="//input[@id='FormView1_txtETD']")
	WebElement ETD_Box; 
	@FindBy(xpath="//input[@id='FormView1_btnInsert']")
	WebElement Insert_button; 
	@FindBy(xpath="//img[@alt='Delete']")
	WebElement Delete_Button; 
	@FindBy(xpath="//table[@class=\"divGrid\"]//tbody//tr[2]//td[2]")
	WebElement Text_Delete; 

	public int navigateToPortCalls() {
		gf.switchToDefault();
		gf.switchToName("menu");
		Home.click();
		gf.waitTillElementVisible(Port_calls);
		Port_calls.click();
		gf.switchToDefault();
		gf.switchToName("cont2");
		gf.waitTillElementVisible(Title_Port_calls);

		boolean value=gf.isDisplayed(Title_Port_calls);
		gf.waitTillElementVisible(Title_Port_calls);

		if(value) {
			return 1;
		}
		else {
			return 0;
		}
	}

	public void CompassOfc_Date() {
		gf.switchToOpenWindow(0);
		gf.switchToName("top");
		gf.waitTillElementVisible(Vessel);
		gf.SelectByVisibleText(Vessel, "Abbotsham Beacon (Greenwich MARINE LIM...)");
		gf.switchToDefault();
		gf.switchToName("cont2");
		gf.switchToName("vslcontent");
		Cmp_portCall.click();
		gf.switchToName("second");



	}
		public int Cmp_add() throws Exception {
		gf.waitTillElementVisible(Cmp_Before_date_box);
		Cmp_Before_date_box.clear();
		Cmp_Before_date_box.sendKeys("18/Mar/2023");
		gf.waitTillElementVisible(Cmp_Aft_date_box);
		Cmp_Aft_date_box.clear();
		Cmp_Aft_date_box.clear();

		Cmp_Aft_date_box.sendKeys("14/Sep/2023");

		Cmp_Add.click();
		gf.switchToOpenWindow(2); 
		Port_name.sendKeys("Usiba");
		ETA_box.sendKeys("01/Feb/2023 00:00");
		ETD_Box.sendKeys("27/Dec/2023 00:00");
		gf.waitTillElementVisible(Insert_button);

		Insert_button.click();
		
		Thread.sleep(2000);
     	gf.switchToOpenWindow(0); 
		gf.switchToName("cont2");
		gf.switchToName("vslcontent");
		gf.switchToName("second");

		gf.waitTillElementVisible(Delete_Button);

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Delete_Button);
		driver.switchTo().alert().accept();

		
		boolean value=gf.isDisplayed(Text_Delete);
		//gf.waitTillElementVisible(Cmp_Before_date_box);

		if(value) {
			return 1;
		}
		else {
			return 0;
		}
	}
}

