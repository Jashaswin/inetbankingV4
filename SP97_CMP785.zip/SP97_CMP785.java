package com.compass.testcases;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.compass.common.GenericFunctions;
import com.compass.common.Utility;
import com.compass.pages.SP97_CMP785_Story;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SP97_CMP785 {
	public WebDriver driver;
	ChromeOptions options;
	GenericFunctions gf;
	SP97_CMP785_Story pg;
	Utility util;
	Properties prop;
	String stageUrl;
	String stagePassword;
	String localAppUrl;
	String onboardUrl;
	String userName;
	String localPassword;
	String title;
	String vessel;
	String onboardUname;
	String onboardPass;
	//String path=".\\Screenshot\\SP95_CMP15476\\";
	String configpath=".\\src\\main\\java\\com\\compass\\config\\config.properties";
	ExtentReports extent = new ExtentReports();
	ExtentTest test;
	WebDriverWait wait;
	String testMethodName;
	Boolean value;
	String descriptiveTestName;
	String text1,text2,text3,text4;
	int i,j,k;
	String excelpath=".\\src\\test\\resources\\CrewData1.xlsx";


	@BeforeSuite
	public void initialConfig() {
		ExtentSparkReporter spark = new ExtentSparkReporter("SP97_CMP785_CompasOnboardArchivix.html");
		spark.config().setDocumentTitle("Compas Integration Test Execution Report");
		spark.config().setTheme(Theme.DARK);
		spark.config().setReportName("Automation Test Report");
		extent.attachReporter(spark);
		extent.setSystemInfo("Test Type ", "DGShippingReport");
		extent.setSystemInfo("Environment", "Local");
		extent.setSystemInfo("Author", "Bhagyashree Mishra");
		extent.attachReporter(spark);
		WebDriverManager.chromedriver().setup();
		ChromeOptions dc = new ChromeOptions();
		dc.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(dc);
		driver.manage().window().maximize();


	}

	@BeforeTest
	public void setUp() throws IOException {

		prop = new Properties();
		FileInputStream ip = new FileInputStream(configpath);
		prop.load(ip);
		localAppUrl = prop.getProperty("localAppUrl");
		onboardUrl = prop.getProperty("onboardUrl");
		userName = prop.getProperty("userName");
		localPassword = prop.getProperty("localPassword");
		onboardUname = prop.getProperty("onboardingUserName");
		onboardPass = prop.getProperty("onboardingPassword");
		stagePassword = prop.getProperty("stagePassword");
		stageUrl = prop.getProperty("stageUrl");
		vessel = prop.getProperty("vessel");
		onboardUname = prop.getProperty("onboardingUserName");
		onboardPass = prop.getProperty("onboardingPassword");
		wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		gf=new GenericFunctions(driver);
		pg=new SP97_CMP785_Story(driver);
		util=new Utility(driver);

	}

	@BeforeMethod
	public void setup(Method method) {
		testMethodName = method.getName();
		descriptiveTestName = method.getAnnotation(Test.class).testName();
		test = extent.createTest(descriptiveTestName);
	}

	@Test(priority=1,testName ="Verify login to Compas Onboarding")

	public void TC_01_loginToOnboarding(){

		try {
			test.info("Login to the Compas Onboard application");
			gf.getUrl(stageUrl);
			gf.waitForPageLoad(300);
			gf.LoginToStage(userName,stagePassword);
			gf.waitForPageLoad(300);
			gf.navigateToStageOnboard();
			gf.waitForPageLoad(500);
			title=gf.getTitle();
			if(title.contains("COMPAS ONBOARD")) {
				test.pass("Logged in to Comaps Onboard Successfully");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
			else {
				test.fail("Login Failed");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}


	}

	@Test(priority=2,testName ="Verify navigation to Port Calls")
	public void Navigate_PortCalls() {


		try {
			i=pg.navigateToPortCalls();
			if(i==1) {
				test.pass("Searched crew is displayed Successfully");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
			}
			else {
				test.fail("Searched crew is not displayed");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}

	}
	@Test(priority=3, testName= "Verify the default Between-date range of Compas Onboard Port Calls should be set to 1 month back")
	public void verify_OnBord_Btw_Date() {
		try {
			long days=gf.Before_DateCalculationFromToday("17-10-2022");

			if(days<=31) {
				test.pass("the default date range of Compas Onboard Port Calls are set to 1 month back");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
			}
			else {
				test.fail("the default date range on the Port Calls are not set to 1 month back");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}
	}

	@Test(priority=4, testName= "Verify the default And-date range of Compas Onboard Port Calls should be set to 1 month after")
	public void verify_OnBord_End_Date() {
		try {

			long days=gf.After_DateCalculationFromToday("17-10-2023");

			if(days<=31) {
				test.pass("the default date range of Compas Onboard Port Calls are set to 1 month after");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
			}
			else {
				test.fail("the default date range on the Port Calls are not set to 1 month after");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}
	}

	@Test(priority=5, testName= "Verify the default date range of Compass Office Port Calls should be set to 1 month back")
	public void verify_Comaps_Date() {
		try {
			pg.CompassOfc_Date();
			long days=gf.Before_DateCalculationFromToday("17-03-2023");

			if(days<=31) {
				test.pass("the default date range on the Port Calls are set to 1 month back");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
			}
			else {
				test.fail("the default date range on the Port Calls are not set to 1 month back");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}
	} 
	@Test(priority=6, testName= "Verify the default date range of Compass Office Port Calls should be set to 1 month After")
	public void verify_Comaps_Afr_Date() {
		try {
			pg.CompassOfc_Date();
			long days=gf.After_DateCalculationFromToday("17-10-2023");

			if(days<=31) {
				test.pass("the default date range on the Port Calls are set to 1 month After");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
			}
			else {
				test.fail("the default date range on the Port Calls are not set to 1 month After");
				test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));

			}
		}catch(Exception e) {
			test.fail(e);
		}
	} 

	    @Test(priority=7, testName= "Verify to edit the Compas office page")
		public void Edit_Ob_Comaps_Date() {
	    	try {
	    		i=pg.Cmp_add();
				if(i==1) {
					test.pass(" edited successfully");
					test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
				}
				else {
					test.fail(" is not Edited");
					test.addScreenCaptureFromPath(util.getScreenShot(driver,testMethodName));
	
				}
			}catch(Exception e) {
				test.fail(e);
			}
		} 
	
	    
	




	@AfterTest
	public void closeDriver() {

		driver.quit();

	}
	@AfterSuite 
	public void tearDown() throws IOException {

		extent.flush();
		//Desktop.getDesktop().browse(new File("SP95_CMP15476_TaskBoardToDoNotesEnhancements.html").toURI());


	}

}
